/*=============================================
=            EDITAR AMBIENTE                  =
=============================================*/
$(".tablas").on("click", ".btnEditarAmbiente", function() {
    var idAmbiente = $(this).attr("idAmbiente");
    var datos = new FormData();
    datos.append("idAmbiente", idAmbiente);
    $.ajax({
        url: "ajax/ambientesAjax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            // console.log(respuesta);
            $("#editarAmbiente").val(respuesta["nombreambiente"]);
            $("#editarUbicacion").val(respuesta["ubicacionambiente"]);
            $("#editarAmbiente").html(respuesta["nombreambiente"]);
            $("#editarUbicacion").html(respuesta["ubicacionambiente"]);
            $("#idAmbiente").val(respuesta["idambiente"]);
            var datosPrograma = new FormData();
            datosPrograma.append("idPrograma", respuesta["idprograma"]);
            $.ajax({
                url: "ajax/programas.ajax.php",
                method: "POST",
                data: datosPrograma,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta) {
                    $("#editarPrograma").val(respuesta["idprograma"]);
                    $("#select2-editarPrograma-container").val(respuesta["idprograma"]);
                    $("#select2-editarPrograma-container").html(respuesta["nombreprograma"]);
                    // $("#EditarPrograma").html(respuesta["nombreprograma"]);
                }
            })
        }
    })
})
/*=============================================
=            ELIMINAR AMBIENTE                  =
=============================================*/
$(".tablas").on("click", ".btnEliminarAmbiente", function() {
    var idAmbiente = $(this).attr("idAmbiente");
    swal({
        title: '¿Desea eliminar el ambiente?',
        text: "Si no está seguro puede cancerlar la acción",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si, borrar ambiente!'
    }).then((result) => {
        if (result.value) {
            window.location = "index.php?ruta=ambientes&idAmbiente=" + idAmbiente;
        }
    })
})
/*=========================
=    VALIDAR AMBIENTE     =
=========================*/
$("#nuevoAmbiente").change(function() {
    // debugger;   
    $(".alert").remove();
    var nombreAmbiente = $(this).val();
    // console.log("nombreAmbiente", nombreAmbiente);
    var datos = new FormData();
    datos.append("nombreAmbiente", nombreAmbiente);
    $.ajax({
        url: "ajax/ambientesAjax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            // console.log("respuesta", respuesta);
            if (respuesta) {
                $("#nuevoAmbiente").parent().after('<div class="alert" style="height: 20px; text-align="center"><font color="#f39c12"><strong>ESTE AMBIENTE YA SE ENCUENTRA REGISTRADO</strong></font></div>');
                $("#nuevoAmbiente").val("");
            }
        }
    })
})

/*=========================
=    VALIDAR EDITAR AMBIENTE     =
=========================*/
var ambienteAntes;
function capturar1(a) {
    // console.log("sel",a);
    ambienteAntes = a;
    $("#editarAmbiente").removeAttr('onclick');
}

$("#editarAmbiente").change(function() {
    // debugger;   
    $(".alert").remove();
    var nombreAmbiente = $(this).val();
    // console.log("nombreAmbiente", nombreAmbiente);
    var datos = new FormData();
    datos.append("nombreAmbiente", nombreAmbiente);
    $.ajax({
        url: "ajax/ambientesAjax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            // console.log("respuesta", respuesta);
            // if (respuesta) {
            //     $("#nuevoAmbiente").parent().after('<div class="alert" style="height: 20px; text-align="center"><font color="#f39c12"><strong>ESTE AMBIENTE YA SE ENCUENTRA REGISTRADO</strong></font></div>');
            //     $("#nuevoAmbiente").val("");
            // }
            if (ambienteAntes == nombreAmbiente.toUpperCase()) {
            
            }else if (respuesta["nombreambiente"] == nombreAmbiente.toUpperCase()){

                $("#editarAmbiente").parent().after('<div class="alert" style="height: 20px; text-align="center"><font color="#f39c12"><strong>ESTE PROGRAMA YA SE ENCUENTRA REGISTRADO</strong></font></div>');
                $("#editarAmbiente").val("");

            }else{

            }
        }
    })
})