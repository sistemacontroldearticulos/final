<footer class="main-footer" style="text-align: center;">
	
	<strong>Copyright &copy; 2018 <a href="inicio" target="_blank" style="text-decoration-color: #25476a">Sistema Control De Articulos</a>.</strong>

	<!-- <br> <-->

	Todos los derechos reservados.


</footer>