<?php

require_once "conexion.php";

class ModeloNovedades
{

    // CREAR NOVEDAD
    public static function mdlCrearNovedad($tabla, $datos)
    {

        // var_dump($datos);

        $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (NumDocumentoUsuario, NumeroFicha, FechaNovedad, Articulo, Estado) VALUES (:NumDocumentoUsuario, :NumeroFicha,  :FechaNovedad, :Articulo, :Estado)");

        $stmt->bindParam(":NumDocumentoUsuario", $datos["NumDocumentoUsuario"], PDO::PARAM_STR);

        $stmt->bindParam(":NumeroFicha", $datos["NumeroFicha"], PDO::PARAM_STR);
        $stmt->bindParam(":FechaNovedad", $datos["FechaNovedad"], PDO::PARAM_STR);
        $stmt->bindParam(":Articulo", $datos["articulo"], PDO::PARAM_STR);
        $stmt->bindParam(":Estado", $datos["Estado"], PDO::PARAM_STR);

        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();
        $stmt = null;

    }

    // CREAR NOVEDAD ARTICULO
    public static function mdlCrearNovedadArticulo($tabla, $datos)
    {

        // var_dump($datos);
        $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (IdArticulo, TipoNovedad, ObservacionNovedad, IdNovedad, fotonovedad) VALUES (:IdArticulo, :TipoNovedad, :ObservacionNovedad, :IdNovedad, :fotonovedad)");

        $stmt->bindParam(":IdArticulo", $datos["IdArticulo"], PDO::PARAM_STR);
        $stmt->bindParam(":TipoNovedad", $datos["TipoNovedad"], PDO::PARAM_STR);
        $stmt->bindParam(":ObservacionNovedad", $datos["ObservacionNovedad"], PDO::PARAM_STR);
        $stmt->bindParam(":IdNovedad", $datos["IdNovedad"], PDO::PARAM_STR);
        $stmt->bindParam(":fotonovedad", $datos["fotonovedad"], PDO::PARAM_STR);


        if ($stmt->execute()) {

            return "ok";

        } else {

            return "error";

        }

        $stmt->close();
        $stmt = null;

    }

    // MOSTRAR NOVEDADES
    public static function mdlMostrarNovedades($tabla, $item, $valor)
    {

        if ($item != null) {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item=:$item");

            $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);

            $stmt->execute();

            return $stmt->fetchAll();

        } else {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");

            $stmt->execute();

            return $stmt->fetchAll();
        }

        $stmt->close();

        $stmt->null();
    }


   // BORRAR NOVEDAD
    static public function mdlBorrarNovedad($tabla, $datos){

        $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE idnovedad = :idnovedad");

        $stmt -> bindParam(":idnovedad", $datos, PDO::PARAM_INT);

        if($stmt -> execute()){

            return "ok";
        
        }else{

            return "error"; 

        }

        $stmt -> close();

        $stmt = null;

    }


    static public function idnovedad(){

        $stmt = Conexion::conectar()->prepare("SELECT MAX(idnovedad) FROM novedad");
        // var_dump($stmt);

        if($stmt -> execute()){

            return  $stmt->fetch();
        
        }else{

            return "error"; 

        }

        $stmt -> close();

        $stmt = null;
    }

    // BORRAR NOVEDAD
    static public function mdlBorrarArticuloNovedad($tabla, $datos){

        $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE idnovedad = :idnovedad");

        $stmt -> bindParam(":idnovedad", $datos, PDO::PARAM_INT);

        if($stmt -> execute()){

            return "ok";
        
        }else{

            return "error"; 

        }

        $stmt -> close();

        $stmt = null;

    }

     public static function mdlMostrarNovedades1($tabla, $item, $valor)
    {

        if ($item != null) {
            $stmt = Conexion::conectar()->prepare("SELECT articulo.tipoarticulo, articulonovedad.tiponovedad, ambiente.nombreambiente, novedad.numeroficha, usuario.nombreusuario,articulonovedad.fotonovedad,articulonovedad.observacionnovedad, novedad.fechanovedad FROM $tabla join articulonovedad on (articulonovedad.idnovedad=novedad.idnovedad) Join articulo on (articulonovedad.idarticulo=articulo.idarticulo) join ficha on (novedad.numeroficha=ficha.numeroficha) join ambiente on(ficha.idambiente=ambiente.idambiente) join usuario on (novedad.numdocumentousuario=usuario.numdocumentousuario) WHERE novedad.$item=:$item");
            

            $stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);
           

            $stmt->execute();

            return $stmt->fetch();

        } else {
            $stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");

            $stmt->execute();

            return $stmt->fetchAll();
        }

        $stmt->close();

        $stmt->null();
    }

}
